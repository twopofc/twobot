const helpdead = (prefix) => {

	return `
╭──────────────╮
 *COMANDOS DO DARK*
╰──────────────╯
 
➸ *${prefix}marcar*
➸ *${prefix}marcar2*
➸ *${prefix}marcar3*
➸ *${prefix}loli00*
➸ *${prefix}loli001*
➸ *${prefix}hentai00*
➸ *${prefix}dono00*
➸ *${prefix}porno00*
➸ *${prefix}boanoite00*
➸ *${prefix}bomdia00*
➸ *${prefix}boatarde00*
➸ *${prefix}mia00*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}akeno*
➸ *${prefix}meme*
➸ *${prefix}lofi*
➸ *${prefix}malkova*
➸ *${prefix}canal*
➸ *${prefix}nsfwloli*
➸ *${prefix}reislin*
➸ *${prefix}limpar*
➸ *${prefix}marcar*
➸ *${prefix}ts (texto que deseja transmitir)*

════════════════════
*BOT DA TDT * 🤗
*Digite ${prefix}dono para mais info*
════════════════════`

}
exports.help1 = help1

